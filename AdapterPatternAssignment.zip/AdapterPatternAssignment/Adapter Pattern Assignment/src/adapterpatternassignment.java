import adapterPatternAssignment.CoffeeMachineInterface;
import adapterPatternAssignment.OldCoffeeMachine;

public class adapterPatternAssignment {
		CoffeeMachineInterface.java
		//My first attempt at code 
		public interface CoffeeMachineInterface {
			 public void chooseFirstSelection(); 
			 public void chooseSecondSelection(); 
		}
		
		//Updated Code 
		OldCoffeeMachine.java
		
		public class OldCoffeeMachine {
			
			public void selectA() {
				System.out.println("A - Selected"); 
			}
			Public void selectB() {
				System.out.println("B - Selected"); 
			}
		}
		//My first attempt at code 
		OldCoffeeMachine.java
		public class OldCoffeeMachine {
		if (OldCoffeeMachine)= void 
		if (select A)
		else void 
		if (select A)
		else void 
		
		



		}



		
		CoffeeTouchscreenAdapter.java
		//Updated Code
		public class CoffeeTouchscreenAdapter implements CoffeeMachineInterface {
			CoffeeMachineInterface { 
				
			OldCoffeeMachine theMachine; 
			
			public CoffeeTouchscreenAdapter(OldCoffeeMachine newMachine) {
				
				theMachine = newMachine; 	
			}
			
			public void chooseFirstSelection() {
				theMachine.selectA(); 
			}
			
			public void chooseSecondSelection() {
				theMachine.selectB(); 
			}
			}
			
			//My first attempt at code 
			public Coffee
			
			
			OldVendingMachine
			chooseFirstSelection() : void; 
			chooseSecondSelection() :void; 
			
			
			
			




		}
		// TODO Auto-generated method stub

	}

}

