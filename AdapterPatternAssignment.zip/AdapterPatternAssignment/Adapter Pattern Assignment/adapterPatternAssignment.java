public class adapterPatternAssignment {
		CoffeeMachineInterface.java
		//My first attempt at code 
		public interface CoffeeMachineInterface {
			 public void chooseFirstSelection(); 
			 public void chooseSecondSelection(); 
		}
		
		//Updated Code 
		OldCoffeeMachine.java
		
		public class OldCoffeeMachine {
			
			public void selectA() {
				System.out.println("A - Selected"); 
			}
			public void selectB() {
				System.out.println("B - Selected"); 
			}
		}
		
		



		}



		
		CoffeeTouchscreenAdapter.java
		//Updated Code
		public class CoffeeTouchscreenAdapter implements CoffeeMachineInterface {
			CoffeeMachineInterface { 
				
			OldCoffeeMachine theMachine; 
			
			public CoffeeTouchscreenAdapter(OldCoffeeMachine newMachine) {
				
				theMachine = newMachine; 	
			}
			
			public void chooseFirstSelection() {
				theMachine.selectA(); 
			}
			
			public void chooseSecondSelection() {
				theMachine.selectB(); 
			}
			}
			
	
			

	}

}
